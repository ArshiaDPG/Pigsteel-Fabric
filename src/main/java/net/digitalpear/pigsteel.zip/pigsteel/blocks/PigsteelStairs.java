package net.digitalpear.pigsteel.blocks;

import net.minecraft.block.BlockState;
import net.minecraft.block.StairsBlock;

public class PigsteelStairs extends StairsBlock {
    public PigsteelStairs(BlockState baseBlockState, Settings settings) {
        super(baseBlockState, settings);
    }
}
