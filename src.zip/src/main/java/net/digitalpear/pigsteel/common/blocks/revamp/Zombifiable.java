package net.digitalpear.pigsteel.common.blocks.revamp;

import net.digitalpear.pigsteel.register.PigsteelBlocks;
import net.digitalpear.pigsteel.register.tags.PigsteelBlockTags;
import net.minecraft.block.BlockState;
import net.minecraft.block.MapColor;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public interface Zombifiable {

    float blockInfluence = 0.1F;

    default boolean canZombify(World world, BlockState state){
        return !world.getDimension().ultrawarm() && PigsteelBlocks.PIGSTEEL_ZOMBIFYING_MAP.containsKey(state.getBlock());
    }

    default void tryZombify(World world, BlockState state, BlockPos pos){
        float chance = 0.9F;
        if (canZombify(world, state)){
            for (BlockPos blockPos : BlockPos.iterate(pos.add(-1, -1, -1), pos.add(1, 1, 1))) {
                if (world.getBlockState(blockPos).isIn(PigsteelBlockTags.WARM_BLOCKS)){
                    chance -= blockInfluence;
                }
                else if (world.getBlockState(blockPos).isIn(PigsteelBlockTags.COLD_BLOCKS)){
                    chance += blockInfluence;
                }
            }

            if (world.getRandom().nextFloat() < chance){
                world.setBlockState(pos, PigsteelBlocks.PIGSTEEL_ZOMBIFYING_MAP.get(state.getBlock()).getStateWithProperties(state));
            }
        }


    }

    ZombificationLevel getZombificationLevel();

    public static enum ZombificationLevel implements StringIdentifiable {
        UNAFFECTED("", MapColor.PURPLE),
        INFECTED("infected", MapColor.PALE_GREEN),
        CORRUPTED("corrupted", MapColor.GREEN),
        ZOMBIFIED("zombified", MapColor.DARK_GREEN);

        ZombificationLevel(String name, MapColor mapColor){
            this.name = name;
            this.mapColor = mapColor;
        }
        String name;
        MapColor mapColor;

        public MapColor getMapColor() {
            return mapColor;
        }

        @Override
        public String asString() {
            return this.name;
        }
    }
}
